package frontend.CustomerGUI;

import project.MasterController;

public class GUIApplication {
	public static void main(String[] args) {
		MasterController m = new MasterController();
	}

}
